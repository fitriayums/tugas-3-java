/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package keliling_persegi_panjang;

import static java.time.Clock.system;
import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class Keliling_persegi_panjang {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     Scanner input = new Scanner (System.in);
   int panjang, lebar, keliling; 
   
   System.out.println("Program Menghitung keliling Persegi");
   System.out.println("===================================");
   
   System.out.println("input nilai panjang persegi panjang :");
   panjang = input.nextInt();
   
   System.out.println("input nilai lebar persegi panjang :");
   lebar = input.nextInt();
   
   keliling = 2*(panjang + lebar);
   
   System.out.println("keliling persegi panjang adalah = " +keliling);
   
   
    }

}


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package keliling_trapesium;

import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author ASUS
 */
public class KELILING_DAN_LUAS_TRAPESIUM {
       
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     Scanner input = new Scanner (System.in);
        System.out.println("Program untuk menghitung luas trapesium :");
        
        String rusuk1 = "";
        rusuk1 = JOptionPane.showInputDialog("Input nilai panjang rusuk atasnya : ");
        int ru1=Integer.parseInt(rusuk1);
        String rusuk2 = "";
        rusuk2 = JOptionPane.showInputDialog("Input nilai panjang rusuk bawahnya : ");
        int ru2=Integer.parseInt(rusuk2);
        String tinggi = "";
        tinggi = JOptionPane.showInputDialog("Input nilai tingginya : ");
        
        int t=Integer.parseInt(tinggi);
        int l1=((ru2-ru1)/2)*t/2;
        int l2=ru1*t;
        int s=(((ru2-ru1)/2)*((ru2-ru1)/2))+(t*t);
        double m=Math.sqrt(s);
        
        System.out.println ("Panjang rusuk atasnya = "+(ru1));
        System.out.println ("Panjang rusuk bawahnya = "+(ru2));
        System.out.println ("Tingginya = "+(t));
        System.out.println ("Luasnya = "+((l1*2)+l2));
        System.out.println ("Kelilingnya = "+((ru1+ru2)+(m*2)));
    
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package luas_persegi_panjang;

import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class LUAS_PERSEGI_PANJANG {
   
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     Scanner input = new Scanner (System.in);
     int panjang, lebar, luas;
     
     System.out.println("Program Menghitung Luas Panjang");
     System.out.println("===============================");
     
     System.out.println("input nilai panjang persegi panjang :");
     panjang = input.nextInt();
     
     System.out.println("input niali lebar persegi panjang :");
     lebar = input.nextInt();
     
     luas = panjang * lebar ;
     
     System.out.println("Luas persegi panjang adalah =" + luas);
             
     
    }
}

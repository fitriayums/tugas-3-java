/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package keliling_dan_luas_lingkaran;

import static java.time.Clock.system;
import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class KELILING_DAN_LUAS_LINGKARAN {
           
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     Scanner input = new Scanner (System.in);
     
     double r;
     double luas, keliling;
     
     System.out.println("Program Menghitung Luas dan Keliling");
     System.out.println("====================================");
     
     System.out.println("Input nilai jari jari");
     r = input.nextInt();
     
     luas = 3.14*r*r;
     keliling = 2*3.14*r;
     
     System.out.println("Luas Lingkaran ="+luas+"cm^2");
     System.out.println("Keliling Lingkaran ="+keliling+"cm");
     
    }
   
}
